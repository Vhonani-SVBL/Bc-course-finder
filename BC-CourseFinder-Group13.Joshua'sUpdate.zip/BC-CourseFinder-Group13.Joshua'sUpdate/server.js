import express from "express";
import fetch from "node-fetch";
import dotenv from "dotenv";
import cors from "cors";
import path from "path";
import { fileURLToPath } from "url";

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
app.use(express.json());
app.use(cors());
app.use(express.static(path.join(__dirname, "public")));

const SYSTEM_PROMPT = `
You are BC CourseFinder™, an AI career guidance assistant for South African Matric students who want to study IT at Belgium Campus.

**Your role:**  
- Help students explore IT career paths (e.g., software developer, data scientist, network engineer).  
- Explain subject requirements (Maths, Physical Science, etc.), qualifications (degree, diploma), and skills needed.  
- Be friendly, supportive, and age‑appropriate for Matric learners.

**Scope boundaries:**  
- ONLY answer IT‑related career questions.  
- If asked about non‑IT topics (sports, entertainment, non‑IT careers), politely say: *"I can only help with IT career guidance. Please ask me about IT careers, subjects, or qualifications."*  
- Do not give personal advice or financial opinions.

**Tone:**  
- Enthusiastic, clear, and encouraging.  
- Use simple language – avoid technical jargon unless explained.

**IMPORTANT FORMATTING RULES:**  
- Use short paragraphs (2-3 sentences max).  
- Use bullet points (with "-" or "•") for lists.  
- Add blank lines between sections.  
- Do NOT write huge blocks of text. Break answers into small, readable chunks.  
- Example of good formatting:  
  "Here are some IT careers you can study with Maths and Science:  
  • Software Developer – learn Java, Python  
  • Data Scientist – focuses on statistics and machine learning  
  • Network Engineer – work with routers and security  

  To get started, you'll need to meet the subject requirements..."
`;

async function getAIResponse(userMessage, history = []) {
  const messages = [
    { role: "system", content: SYSTEM_PROMPT },
    ...history,
    { role: "user", content: userMessage }
  ];

  // 1. Try OpenRouter (GPT-3.5 or similar)
  if (process.env.OPENROUTER_API_KEY) {
    try {
      const res = await fetch("https://openrouter.ai/api/v1/chat/completions", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${process.env.OPENROUTER_API_KEY}`,
          "HTTP-Referer": "http://localhost:3000",
        },
        body: JSON.stringify({
          model: "openai/gpt-3.5-turbo",
          messages: messages,
          temperature: 0.7
        })
      });
      if (res.ok) {
        const data = await res.json();
        return data.choices[0].message.content;
      }
    } catch (e) { console.error("OpenRouter error:", e.message); }
  }

  // 2. Fallback to Hugging Face (Mistral or similar)
  if (process.env.HF_TOKEN) {
    try {
      const res = await fetch("https://api-inference.huggingface.co/models/mistralai/Mistral-7B-Instruct-v0.2", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${process.env.HF_TOKEN}`
        },
        body: JSON.stringify({ inputs: `<s>[INST] ${SYSTEM_PROMPT} \n\n User: ${userMessage} [/INST]` })
      });
      if (res.ok) {
        const data = await res.json();
        return data[0].generated_text.split('[/INST]').pop().trim();
      }
    } catch (e) { console.error("HF error:", e.message); }
  }

  return null; 
}

app.post("/chat", async (req, res) => {
  try {
    const { message, history } = req.body;
    if (!message) return res.status(400).json({ reply: "Ask me anything about IT!" });

    let reply = await getAIResponse(message, history || []);

    if (!reply) {
      reply = "I'm currently offline, but generally: Software Development is a great path if you enjoy logic and problem solving!";
    }

    res.json({ reply });
  } catch (error) {
    console.error("Server error:", error);
    res.status(500).json({ reply: "I'm having a technical glitch. Please try again in a moment!" });
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`http://localhost:${PORT}`));